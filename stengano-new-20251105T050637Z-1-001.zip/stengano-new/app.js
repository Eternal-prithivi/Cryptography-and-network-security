document.addEventListener('DOMContentLoaded', () => {
    // --- Element Selection ---
    const tabs = document.querySelectorAll('.tab-button');
    const tabPanels = document.querySelectorAll('.tab-panel');
    const spinner = document.getElementById('spinner');
    const resultsPanel = document.getElementById('results-panel');
    const resultsContent = document.getElementById('results-content');
    const progressBar = document.getElementById('progress-bar');
    const spinner_text = document.getElementById('spinner-text');

    // --- Tab Switching Logic ---
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const targetPanel = document.getElementById(tab.dataset.tab);
            tabPanels.forEach(p => p.classList.remove('active'));
            targetPanel.classList.add('active');
            resultsPanel.style.display = 'none';
        });
    });

    // --- Helper Functions ---
    function showSpinner(text = 'Processing...') {
        spinner_text.textContent = text;
        progressBar.style.width = '0%';
        spinner.style.display = 'flex';
    }
    function hideSpinner() { spinner.style.display = 'none'; }
    function updateProgress(percentage) { progressBar.style.width = `${percentage}%`; }
    function arrayBufferToBase64(buffer) {
        let binary = '';
        const bytes = new Uint8Array(buffer);
        for (let i = 0; i < bytes.byteLength; i++) { binary += String.fromCharCode(bytes[i]); }
        return window.btoa(binary);
    }
    function base64ToArrayBuffer(base64) {
        const binary_string = window.atob(base64);
        const len = binary_string.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) { bytes[i] = binary_string.charCodeAt(i); }
        return bytes.buffer;
    }

    // --- File Drop Zone & Preview Logic ---
    function setupDropZone(dropZoneId, inputId, previewContainerId, infoId) {
        const dropZone = document.getElementById(dropZoneId);
        const fileInput = document.getElementById(inputId);
        const previewContainer = document.getElementById(previewContainerId);
        const prompt = dropZone.querySelector('.drop-zone-prompt');
        const info = document.getElementById(infoId);

        dropZone.addEventListener('click', () => fileInput.click());
        dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
        ['dragleave', 'dragend'].forEach(type => dropZone.addEventListener(type, () => dropZone.classList.remove('drag-over')));
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('drag-over');
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileChange({ target: fileInput });
            }
        });
        fileInput.addEventListener('change', handleFileChange);

        function handleFileChange(e) {
            const files = e.target.files;
            if (!files || files.length === 0) {
                if(info) info.style.display = 'none';
                if(previewContainer) previewContainer.innerHTML = '';
                return;
            }
            if (previewContainer) {
                previewContainer.innerHTML = '';
                Array.from(files).forEach(file => {
                    if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = () => {
                            const img = document.createElement('img');
                            img.src = reader.result;
                            img.classList.add('image-preview');
                            img.style.display = 'block';
                            previewContainer.appendChild(img);
                        };
                        reader.readAsDataURL(file);
                    }
                });
            }
            const file = files[0];
            prompt.textContent = files.length > 1 ? `${files.length} files selected` : file.name;
            if (info) {
                const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                info.textContent = `Type: ${file.type || 'N/A'}, Size: ${sizeInMB} MB`;
                info.style.display = 'block';
            }
        }
    }
    setupDropZone('hide-image-drop-zone', 'hide-image-input', 'hide-preview-container', null);
    setupDropZone('secret-file-drop-zone', 'secret-file-input', null, 'file-info-preview');
    setupDropZone('extract-image-drop-zone', 'extract-image-input', 'extract-preview-container', null);

    // --- Input Mode Switching ---
    const inputModeButtons = document.querySelectorAll('.input-mode-button');
    const inputPanels = document.querySelectorAll('.input-panel');
    let activeInputMode = 'file';
    inputModeButtons.forEach(button => {
        button.addEventListener('click', () => {
            inputModeButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            activeInputMode = button.dataset.mode;
            inputPanels.forEach(panel => {
                panel.id === `${activeInputMode}-input-panel` ? panel.classList.add('active') : panel.classList.remove('active');
            });
        });
    });

    // --- Password Strength Meter & Audio Recording ---
    // (These sections are unchanged but included for completeness)
    const hidePasswordInput = document.getElementById('hide-password');
    const strengthBar = document.getElementById('password-strength-bar');
    hidePasswordInput.addEventListener('input', () => {
        const password = hidePasswordInput.value;
        let score = 0;
        if (!password) { strengthBar.style.width = '0%'; return; }
        if (password.length > 8) score++;
        if (/[a-z]/.test(password)) score++;
        if (/[A-Z]/.test(password)) score++;
        if (/[0-9]/.test(password)) score++;
        if (/[^a-zA-Z0-9]/.test(password)) score++;
        strengthBar.className = 'strength-bar';
        if (score <= 2) { strengthBar.style.width = '25%'; strengthBar.classList.add('weak'); }
        else if (score <= 4) { strengthBar.style.width = '75%'; strengthBar.classList.add('medium'); }
        else { strengthBar.style.width = '100%'; strengthBar.classList.add('strong'); }
    });
    const recordButton = document.getElementById('record-button');
    const stopButton = document.getElementById('stop-button');
    const audioPlayback = document.getElementById('audio-playback');
    let mediaRecorder, audioChunks = [], recordedAudioBlob = null;
    recordButton.addEventListener('click', async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);
            mediaRecorder.start();
            mediaRecorder.addEventListener("dataavailable", event => audioChunks.push(event.data));
            mediaRecorder.addEventListener("stop", () => {
                recordedAudioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                const audioUrl = URL.createObjectURL(recordedAudioBlob);
                audioPlayback.src = audioUrl;
                audioPlayback.style.display = 'block';
                audioChunks = [];
                stream.getTracks().forEach(track => track.stop());
            });
            recordButton.disabled = true; stopButton.disabled = false;
        } catch (err) { alert('Microphone access was denied. Please allow it in your browser settings.'); }
    });
    stopButton.addEventListener('click', () => {
        if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
        recordButton.disabled = false; stopButton.disabled = true;
    });

    // --- Core Cryptography Logic ---
    async function getCryptoKey(password, salt) {
        const keyMaterial = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), { name: 'PBKDF2' }, false, ['deriveKey']);
        return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: 100000, hash: 'SHA-256' }, keyMaterial, { name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
    }
    async function encryptData(password, data) {
        const salt = crypto.getRandomValues(new Uint8Array(16));
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const key = await getCryptoKey(password, salt);
        const encryptedData = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, data);
        const result = new Uint8Array(salt.length + iv.length + encryptedData.byteLength);
        result.set(salt, 0);
        result.set(iv, salt.length);
        result.set(new Uint8Array(encryptedData), salt.length + iv.length);
        return result;
    }
    async function decryptData(password, encryptedData) {
        try {
            const salt = encryptedData.slice(0, 16);
            const iv = encryptedData.slice(16, 28);
            const data = encryptedData.slice(28);
            const key = await getCryptoKey(password, salt);
            return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, data));
        } catch (e) { return null; }
    }
    
    // --- ADVANCED STEGANOGRAPHY LOGIC ---
    async function getShuffledCoords(imageSize, password) {
        const { width, height } = imageSize;
        const coords = Array.from({ length: width * height }, (_, i) => [i % width, Math.floor(i / width)]);
        const hashBuffer = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(password));
        const seed = new DataView(hashBuffer).getUint32(0, false);
        function mulberry32(a) { return function() { var t = a += 0x6D2B79F5; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; } }
        const prng = mulberry32(seed);
        for (let i = coords.length - 1; i > 0; i--) {
            const j = Math.floor(prng() * (i + 1));
            [coords[i], coords[j]] = [coords[j], coords[i]];
            if (i % 50000 === 0) { // The fix to prevent freezing
                await new Promise(resolve => setTimeout(resolve, 0));
            }
        }
        return coords;
    }

    async function hideDataInCanvas(ctx, dataToHide, password, progressCallback) {
        const { width, height } = ctx.canvas;
        const imageData = ctx.getImageData(0, 0, width, height);
        const pixels = imageData.data;
        showSpinner('Generating secret path...');
        await new Promise(r => setTimeout(r, 0));
        const shuffledCoords = await getShuffledCoords({ width, height }, password);
        const dataSize = dataToHide.length;
        const totalData = new Uint8Array(4 + dataSize);
        new DataView(totalData.buffer).setUint32(0, dataSize, false);
        totalData.set(dataToHide, 4);
        if (totalData.length * 8 > shuffledCoords.length * 3) throw new Error("Data is too large for the combined image size.");
        let dataBitIndex = 0; const totalBits = totalData.length * 8;
        while(dataBitIndex < totalBits) {
            const coordIndex = Math.floor(dataBitIndex / 3), channelIndex = dataBitIndex % 3;
            if(coordIndex >= shuffledCoords.length) throw new Error("Coordinate index out of bounds during hiding.");
            const [x, y] = shuffledCoords[coordIndex], pixelIndex = (y * width + x) * 4;
            const bit = (totalData[Math.floor(dataBitIndex / 8)] >> (7 - (dataBitIndex % 8))) & 1;
            pixels[pixelIndex + channelIndex] = (pixels[pixelIndex + channelIndex] & 0xFE) | bit;
            if (dataBitIndex % 20000 === 0) await new Promise(r => requestAnimationFrame(() => { progressCallback(dataBitIndex / totalBits * 100); r(); }));
            dataBitIndex++;
        }
        ctx.putImageData(imageData, 0, 0);
    }
    
    async function extractDataFromCanvas(ctx, password, progressCallback) {
        const { width, height } = ctx.canvas;
        const imageData = ctx.getImageData(0, 0, width, height);
        const pixels = imageData.data;
        showSpinner('Generating secret path...');
        await new Promise(r => setTimeout(r, 0));
        const shuffledCoords = await getShuffledCoords({ width, height }, password);
        let bits = [], i = 0;
        for(i=0; i<32; i++) {
            const coordIndex = Math.floor(i / 3), channelIndex = i % 3;
            if(coordIndex >= shuffledCoords.length) throw new Error("Could not extract size header.");
            const [x, y] = shuffledCoords[coordIndex], pixelIndex = (y * width + x) * 4;
            bits.push(pixels[pixelIndex + channelIndex] & 1);
        }
        const dataSize = parseInt(bits.join(''), 2);
        if (isNaN(dataSize) || dataSize <= 0) throw new Error("Invalid data size. Password may be wrong.");
        bits = []; const totalBitsToExtract = dataSize * 8;
        if ((32 + totalBitsToExtract) > shuffledCoords.length * 3) throw new Error("Data size is too large for image. Password may be wrong.");
        for(i=0; i<totalBitsToExtract; i++) {
            const bitIndexWithHeader = i + 32, coordIndex = Math.floor(bitIndexWithHeader / 3), channelIndex = bitIndexWithHeader % 3;
            if(coordIndex >= shuffledCoords.length) throw new Error("Unexpected end of image during data extraction.");
            const [x, y] = shuffledCoords[coordIndex], pixelIndex = (y * width + x) * 4;
            bits.push(pixels[pixelIndex + channelIndex] & 1);
            if (i % 20000 === 0) await new Promise(r => requestAnimationFrame(() => { progressCallback(i / totalBitsToExtract * 100); r(); }));
        }
        const hiddenData = new Uint8Array(dataSize);
        for (i = 0; i < dataSize; i++) {
            const byteBits = bits.slice(i * 8, (i + 1) * 8);
            if(byteBits.length < 8) continue;
            hiddenData[i] = parseInt(byteBits.join(''), 2);
        }
        return hiddenData;
    }

    // --- Visualization & Main Button Logic ---
    // ... (This logic is unchanged from the final version and is included for completeness)
    async function createVisualization(imageSize, password, dataLength, container) {
        const totalBits = (dataLength + 4) * 8;
        const pixelsUsed = Math.ceil(totalBits / 3);
        const shuffledCoords = await getShuffledCoords(imageSize, password);
        const canvas = document.createElement('canvas');
        const aspectRatio = imageSize.height / imageSize.width;
        canvas.width = Math.min(imageSize.width, 500); canvas.height = canvas.width * aspectRatio;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = 'black'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = 'red';
        const scaleX = canvas.width / imageSize.width, scaleY = canvas.height / imageSize.height;
        for (let i = 0; i < pixelsUsed; i++) {
            if(i >= shuffledCoords.length) break;
            const [x, y] = shuffledCoords[i];
            ctx.fillRect(Math.floor(x * scaleX), Math.floor(y * scaleY), Math.max(1, scaleX), Math.max(1, scaleY));
        }
        const title = document.createElement('h4'); title.textContent = 'Hidden Data Location Map';
        container.appendChild(title); container.appendChild(canvas);
    }
    async function stitchImages(imageFiles, progressCallback) {
        const imageBitmaps = await Promise.all(Array.from(imageFiles).map(file => createImageBitmap(file)));
        let totalWidth = 0, maxHeight = 0;
        imageBitmaps.forEach(bmp => { totalWidth += bmp.width; if (bmp.height > maxHeight) maxHeight = bmp.height; });
        const canvas = document.createElement('canvas');
        canvas.width = totalWidth; canvas.height = maxHeight;
        const ctx = canvas.getContext('2d');
        let currentX = 0;
        for (let i = 0; i < imageBitmaps.length; i++) {
            const bmp = imageBitmaps[i];
            ctx.drawImage(bmp, currentX, 0);
            currentX += bmp.width;
            progressCallback((i + 1) / imageBitmaps.length * 100);
        }
        return ctx;
    }
    document.getElementById('hide-button').addEventListener('click', async () => {
        const coverImageFiles = document.getElementById('hide-image-input').files;
        const password = document.getElementById('hide-password').value;
        let secretFileBlob;
        if (activeInputMode === 'file') {
            secretFileBlob = document.getElementById('secret-file-input').files[0];
            if (!secretFileBlob) return alert('Please select a secret file.');
        } else if (activeInputMode === 'text') {
            const text = document.getElementById('secret-text-input').value;
            if (!text) return alert('Please enter some secret text.');
            secretFileBlob = new Blob([text], { type: 'text/plain' });
            secretFileBlob.name = 'message.txt';
        } else if (activeInputMode === 'audio') {
            if (!recordedAudioBlob) return alert('Please record an audio message.');
            secretFileBlob = recordedAudioBlob;
            secretFileBlob.name = `recording.wav`;
        }
        if (!coverImageFiles || coverImageFiles.length === 0 || !password) return alert('Please provide at least one cover image and a password.');
        showSpinner('Packaging and Encrypting...');
        try {
            const fileBuffer = await secretFileBlob.arrayBuffer();
            const base64Data = arrayBufferToBase64(fileBuffer);
            const payload = { name: secretFileBlob.name, type: secretFileBlob.type, data: base64Data };
            const payloadString = JSON.stringify(payload);
            const secretData = new TextEncoder().encode(payloadString);
            const encryptedData = await encryptData(password, secretData);
            showSpinner('Stitching Cover Images...');
            const filmStripCtx = await stitchImages(coverImageFiles, (p) => updateProgress(p));
            showSpinner('Hiding Data in Image...');
            await hideDataInCanvas(filmStripCtx, encryptedData, password, updateProgress);
            updateProgress(100);
            filmStripCtx.canvas.toBlob(blob => {
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url; a.download = 'film_strip_stego.png'; a.click();
                URL.revokeObjectURL(url); hideSpinner();
            }, 'image/png');
        } catch (e) { hideSpinner(); alert('Error: ' + e.message); }
    });
    document.getElementById('extract-button').addEventListener('click', async () => {
        const stegoImageFile = document.getElementById('extract-image-input').files[0];
        const password = document.getElementById('extract-password').value;
        if (!stegoImageFile || !password) return alert('Please provide a stego-image and a password.');
        showSpinner('Extracting...');
        try {
            const stegoImage = await createImageBitmap(stegoImageFile);
            const canvas = document.createElement('canvas');
            canvas.width = stegoImage.width; canvas.height = stegoImage.height;
            const ctx = canvas.getContext('2d'); ctx.drawImage(stegoImage, 0, 0);
            const extractedData = await extractDataFromCanvas(ctx, password, updateProgress);
            updateProgress(100);
            resultsContent.innerHTML = '';
            await createVisualization({width: stegoImage.width, height: stegoImage.height}, password, extractedData.length, resultsContent);
            const totalBits = (extractedData.length + 4) * 8, pixelsUsed = Math.ceil(totalBits / 3), totalPixels = stegoImage.width * stegoImage.height;
            const dataInfo = document.createElement('div');
            dataInfo.innerHTML = `
                <h4>✅ Encrypted Data Found!</h4>
                <p>Modified <strong>${pixelsUsed.toLocaleString()}</strong> pixels out of <strong>${totalPixels.toLocaleString()}</strong> total to hide <strong>${totalBits.toLocaleString()}</strong> bits.</p>
                <p>The raw encrypted data is below. Click to decrypt.</p>
                <textarea class="encrypted-data-view" readonly>${Array.from(extractedData).map(b => b.toString(16).padStart(2, '0')).join(' ')}</textarea>
                <button id="decrypt-button" class="action-button">Decrypt</button>
            `;
            resultsContent.appendChild(dataInfo); resultsPanel.style.display = 'block';
            document.getElementById('decrypt-button').addEventListener('click', async () => {
                showSpinner('Decrypting...');
                const decryptedData = await decryptData(password, extractedData);
                const resultDiv = document.createElement('div');
                if (decryptedData) {
                    const payloadString = new TextDecoder().decode(decryptedData);
                    const payload = JSON.parse(payloadString);
                    const fileContent = base64ToArrayBuffer(payload.data);
                    const blob = new Blob([fileContent], { type: payload.type });
                    const url = URL.createObjectURL(blob);
                    resultDiv.innerHTML = `<h4>✅ Decryption Successful!</h4><p>Your secret file is ready to be downloaded with its original name.</p><a href="${url}" download="${payload.name}" class="action-button">Download ${payload.name}</a>`;
                } else {
                    resultDiv.innerHTML = `<h4>❌ Decryption Failed!</h4><p>The password was incorrect or the file is corrupt.</p>`;
                }
                dataInfo.innerHTML = ''; dataInfo.appendChild(resultDiv); hideSpinner();
            });
        } catch(e) { alert('Error during extraction: ' + e.message); } finally { hideSpinner(); }
    });
});
